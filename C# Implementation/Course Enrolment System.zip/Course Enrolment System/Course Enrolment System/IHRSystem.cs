﻿public interface IHRSystem
{
    void GetStaffRole(string staffId);
    void GetAccessRights(string userId);
}