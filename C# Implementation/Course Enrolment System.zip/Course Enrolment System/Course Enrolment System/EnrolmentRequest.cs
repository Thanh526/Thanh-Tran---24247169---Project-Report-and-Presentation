﻿using System;
using System.Collections.Generic;

public class EnrolmentRequest
{
    public string RequestId { get; private set; }
    public string StudentId { get; private set; }
    public DateTime SubmissionDate { get; private set; }
    public EnrolmentStatus EnrolmentStatus { get; private set; }
    private List<Course> _requestedCourses = new List<Course>();

    public EnrolmentRequest(string requestId, string studentId, List<Course> requestedCourses)
    {
        this.RequestId = requestId;
        this.StudentId = studentId;
        this._requestedCourses.AddRange(requestedCourses);
        this.SubmissionDate = DateTime.Now;
        this.EnrolmentStatus = EnrolmentStatus.Draft;
    }

    public void Submit()
    {
        if (EnrolmentStatus == EnrolmentStatus.Draft)
        {
            EnrolmentStatus = EnrolmentStatus.Pending;
            this.SubmissionDate = DateTime.Now;
        }
    }
    public void SetStatus(EnrolmentStatus newStatus)
    {
        this.EnrolmentStatus = newStatus;
    }
    public void Cancel()
    {
        if (EnrolmentStatus == EnrolmentStatus.Pending || EnrolmentStatus == EnrolmentStatus.Draft)
        {
            EnrolmentStatus = EnrolmentStatus.Cancelled;
            Console.WriteLine($"Request {RequestId} has been cancelled.");
        }
    }
    public void AddCourse(Course course)
    {
        if (!_requestedCourses.Contains(course))
        {
            _requestedCourses.Add(course);
        }
    }
    public List<Course> GetRequestedCourses()
    {
        return _requestedCourses;
    }

    public void Resubmit()
    {
        if (this.EnrolmentStatus == EnrolmentStatus.Rejected || this.EnrolmentStatus == EnrolmentStatus.Cancelled)
        {
            this.EnrolmentStatus = EnrolmentStatus.Pending;

            this.SubmissionDate = DateTime.Now;

            Console.WriteLine($"Request {RequestId} has been resubmitted for review.");
        }
        else
        {
            Console.WriteLine($"Cannot resubmit. Current status is: {EnrolmentStatus}");
        }
    }
}