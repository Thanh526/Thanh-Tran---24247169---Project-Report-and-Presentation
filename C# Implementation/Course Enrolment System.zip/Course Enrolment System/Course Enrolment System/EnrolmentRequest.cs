﻿public class EnrolmentRequest
{
    public string RequestId { get; private set; }
    public DateTime SubmissionDate { get; private set; }
    public EnrolmentStatus EnrolmentStatus { get; private set; }

    public void Submit() { }
    public void Resubmit() { }
    public void Cancel() { }
}