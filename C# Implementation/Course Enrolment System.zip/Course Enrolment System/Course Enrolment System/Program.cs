﻿using System;

class Program
{
    static void Main(string[] args)
    {
        IAuthSystem authSystem = new UserAdapter();
        AuthService authService = new AuthService(authSystem);

        while (true)
        {
            Console.WriteLine("\n----- LOGIN SYSTEM -----");

            Console.Write("Username: ");
            string username = Console.ReadLine();

            Console.Write("Password: ");
            string password = Console.ReadLine();

            User user = authService.Login(username, password);

            if (user == null)
            {
                Console.WriteLine("Login failed.");
                continue;
            }

            Console.WriteLine("Login successful!");

            if (user is Student student)
            {
                StudentMenu(student);
            }
            else if (user is RegistryStaff registry)
            {
                RegistryMenu(registry);
            }

            // after logout → loop returns here (back to login screen)
        }
    }
    static void StudentMenu(Student student)
    {
        CourseService courseService =
            new CourseService(new CourseInfoAdapter());

        ValidationService validationService =
            new ValidationService();

        while (true)
        {
            Console.WriteLine("\n----- STUDENT MENU -----");
            Console.WriteLine("1. Search Courses");
            Console.WriteLine("2. View Course Details");
            Console.WriteLine("3. Select Course");
            Console.WriteLine("4. View Selected Courses");
            Console.WriteLine("5. Submit Enrolment");
            Console.WriteLine("6. View Enrolment Status");
            Console.WriteLine("0. Logout");

            Console.Write("Choose: ");
            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    student.SearchCourses(courseService);
                    break;

                case "2":
                    Console.Write("Enter course code: ");
                    string code = Console.ReadLine();

                    student.ViewCourseDetails(courseService, code);
                    break;

                case "3":
                    Console.Write("Enter course code: ");
                    string c = Console.ReadLine();

                    Course course = courseService.GetCourse(c);

                    if (course != null)
                    {
                        student.SelectCourse(course, validationService);
                    }
                    else
                    {
                        Console.WriteLine("Course not found.");
                    }
                    break;

                case "4":
                    student.ViewEnrolledList();
                    break;

                case "5":
                    student.SubmitEnrolment();
                    break;

                case "6":
                    student.ViewEnrolmentStatus();
                    break;

                case "0":
                    Console.WriteLine("Logging out...");
                    return; // goes back to login screen

                default:
                    Console.WriteLine("Invalid option");
                    break;
            }
        }
    }

    static void RegistryMenu(RegistryStaff staff)
    {
        IFinanceSystem financeSystem = new FinanceSystemAdapter();
        FinanceService financeService = new FinanceService(financeSystem);
        EnrolmentService enrolmentService = new EnrolmentService(
            new ValidationService(),
            new FinanceService(new FinanceSystemAdapter()),
            new NotificationService()
        );

        NotificationService notificationService = new NotificationService();

        while (true)
        {
            Console.WriteLine("\n----- REGISTRY MENU -----");
            Console.WriteLine("1. Monitor Enrolments");
            Console.WriteLine("2. Review Enrolment Request");
            Console.WriteLine("3. Check Student Eligibility");
            Console.WriteLine("4. Approve Request");
            Console.WriteLine("5. Reject Request");
            Console.WriteLine("0. Logout");

            Console.Write("Choose: ");
            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    staff.MonitorEnrolments();
                    break;

                case "2":
                    Console.Write("Enter Request ID: ");
                    string rid = Console.ReadLine();
                    staff.ReviewEnrolmentRequest(rid);
                    break;

                case "3":
                    Console.Write("Enter Request ID: ");
                    string idCheck = Console.ReadLine();
                    staff.CheckStudentEligibility(
                        "S000001",
                        financeService
                    );
                    break;

                case "4":
                    Console.Write("Enter Request ID: ");
                    string approveId = Console.ReadLine();

                    staff.ApproveEnrolment(
                        approveId,
                        notificationService
                    );
                    break;

                case "5":
                    Console.Write("Enter Request ID: ");
                    string rejectId = Console.ReadLine();

                    staff.RejectEnrolment(
                        rejectId,
                        notificationService
                    );
                    break;

                case "0":
                    return;

                default:
                    Console.WriteLine("Invalid option");
                    break;
            }
        }
    }
}