﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main(string[] args)
    {
        AuditService audit = new AuditService();

        // Create a course and add a prerequisite manually
        Course ense706 = new Course("ENSE706", "Data Process and Software Modelling", 15, 20);
        ense706.Description = "This course introduces the Unified Modeling Language (UML) as a key tool for requirements analysis, object-oriented software design, and identifying use cases.";
        ense706.AddPrerequisite("ENSE602");

        // Create a student and staff
        Student student = new Student("U001", "AdamTran", "pass123", "12345678", "BCIS", StudentType.Domestic);
        RegistryStaff staff = new RegistryStaff("ST01", "Admin_Sarah", "admin789", "1234567", "Registry", "WZ321");

        // A list to simulate the "Database" of all system requests
        List<EnrolmentRequest> systemRequests = new List<EnrolmentRequest>();

        Console.WriteLine("=== AUT ENROLMENT SYSTEM START ===\n");

        // Student action
        student.Login("AdamTran", "pass123", audit);

        // Simulate searching and viewing
        student.ViewCourses(ense706);

        Console.WriteLine("\nStudent is selecting COMP603...");
        student.SelectCourses(ense706);
        student.ViewEnrolledList();

        // Submit the enrolment
        student.SubmitEnrolment(audit);

        // Create a request
        var demoReq = new EnrolmentRequest("REQ-ABC12", student.StudentId, new List<Course> { ense706 });
        demoReq.Submit(); // Set to Pending
        systemRequests.Add(demoReq);

        // Registry staff action
        Console.WriteLine("\nSwitching to registry staff view...");
        staff.Login("Admin_Sarah", "admin789", audit);

        // Monitor the dashboard
        staff.MonitorEnrolments(systemRequests);

        // Review the specific request
        staff.ReviewEnrolmentRequest(student, demoReq);

        // Final Approval
        staff.ApproveEnrolment(demoReq, audit);

        // Check history
        student.ViewEnrolmentStatus();

        Console.WriteLine("\n=== DEMO END ===");
        student.Logout(audit);
    }
}