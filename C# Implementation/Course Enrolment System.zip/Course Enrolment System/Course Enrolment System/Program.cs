﻿//using System;
//using System.Collections;
//using System.Collections.Generic;

//class Program
//{
//    static void Main(string[] args)
//    {
//        AuditService audit = new AuditService();

//        // 1. Create a List of Courses for the demo
//        List<Course> courseList = new List<Course>
//        {
//            new Course("ENSE706", "Data Process and Software Modelling", 15, 20),
//            new Course("COMP716", "Highly Secure Systems", 15, 40),
//            new Course("COMP721", "Web Development", 15, 100)
//        };

//        // Add some descriptions/prereqs to make it look real
//        courseList[0].Description = "This course introduces the Unified Modeling Language (UML) as a key tool for requirements analysis, object-oriented software design, and identifying use cases.";
//        courseList[0].AddPrerequisite("ENSE602");

//        Student student = new Student("U001", "AdamTran", "pass123", "12345678", "BCIS", StudentType.Domestic);
//        RegistryStaff staff = new RegistryStaff("ST01", "Admin_Sarah", "admin789", "1234567", "Registry", "WZ321");

//        List<EnrolmentRequest> systemRequests = new List<EnrolmentRequest>();

//        bool running = true;

//        while (running)
//        {
//            Console.Clear();
//            Console.WriteLine("===============================================");
//            Console.WriteLine("      AUT ENROLMENT SYSTEM - LOGIN PORTAL      ");
//            Console.WriteLine("===============================================");
//            Console.WriteLine("1. Student login");
//            Console.WriteLine("2. Registry staff login");
//            Console.WriteLine("3. Exit demo");
//            Console.Write("\nSelect an option (1-3): ");

//            string choice = Console.ReadLine();

//            switch (choice)
//            {
//                case "1":
//                    HandleStudentFlow(student, courseList, audit, systemRequests);
//                    break;
//                case "2":
//                    HandleStaffFlow(staff, student, audit, systemRequests);
//                    break;
//                case "3":
//                    running = false;
//                    break;
//                default:
//                    Console.WriteLine("Invalid choice. Press Enter to try again.");
//                    Console.ReadLine();
//                    break;
//            }
//        }
//    }

//    // --- STUDENT INTERACTIVE FLOW ---
//    static void HandleStudentFlow(Student s, List<Course> courses, AuditService audit, List<EnrolmentRequest> requests)
//    {
//        Console.Clear();
//        Console.WriteLine("--- STUDENT PORTAL ---");
//        Console.Write("Username: ");
//        string username = Console.ReadLine();
//        Console.Write("Password: ");
//        string password = Console.ReadLine();

//        if (username == s.Username)
//        {
//            s.Login(username, password, audit);

//            string choice = "1";
//            while (choice != "2")
//            {
//                Console.WriteLine("\n1. Search Courses");
//                Console.WriteLine("2. Logout");
//                Console.Write("Choice: ");
//                choice = Console.ReadLine();
//                if (choice == "1")
//                {
//                    // --- 1. DISPLAY LIST ---
//                    Console.WriteLine("\n--- Available Courses in " + s.Programme + " ---");
//                    foreach (var course in courses)
//                    {
//                        Console.WriteLine($"- [{course.CourseCode}] {course.CourseName} ({course.Capacity - course.EnrolledCount} spots left)");
//                    }

//                    Console.WriteLine("\nNext step");
//                    Console.WriteLine("1. Select Courses");
//                    Console.WriteLine("2. View Selected List");
//                    Console.WriteLine("3. Logout");
//                    choice = Console.ReadLine();
//                    Console.Write("Choice: ");
//                    if (choice == "1")
//                    {
//                        bool selecting = true;
//                        while (selecting)
//                        {
//                            // --- 1. SELECTION LOGIC ---
//                            Console.Write("\nEnter Course Code to select: ");
//                            string inputCode = Console.ReadLine().ToUpper();

//                            // Find the course in the available list
//                            Course selected = courses.Find(c => c.CourseCode == inputCode);

//                            if (selected != null)
//                            {
//                                s.SelectCourses(selected); // Student class handles internal list

//                                // --- 2. INNER NAVIGATION LOOP ---
//                                bool innerAction = true;
//                                while (innerAction)
//                                {
//                                    Console.WriteLine("\nWhat would you like to do next?");
//                                    Console.WriteLine("1. Select another course");
//                                    Console.WriteLine("2. View Selected List");
//                                    Console.WriteLine("3. Proceed to Submit Enrolment");
//                                    Console.Write("Choice: ");

//                                    string subChoice = Console.ReadLine();

//                                    if (subChoice == "1")
//                                    {
//                                        innerAction = false; // Go back to "Enter Course Code"
//                                    }
//                                    else if (subChoice == "2")
//                                    {
//                                        s.ViewEnrolledList(); // Show the current "cart"
//                                                              // Stays in this loop so they can then pick 1 or 3
//                                    }
//                                    else if (subChoice == "3")
//                                    {
//                                        innerAction = false;
//                                        selecting = false; // Break both loops to move to submission
//                                    }
//                                    else
//                                    {
//                                        Console.WriteLine("Invalid choice. Please select 1, 2, or 3.");
//                                    }
//                                }
//                            }
//                            else
//                            {
//                                // --- 3. WRONG INPUT HANDLING ---
//                                Console.WriteLine($"\n[!] Error: Course code '{inputCode}' not found. Please try again.");
//                            }
//                        }

//                        // --- 4. SUBMISSION PHASE ---
//                        Console.WriteLine("\n--- Finalizing Enrolment ---");
//                        var demoReq = new EnrolmentRequest("REQ-" + Guid.NewGuid().ToString().Substring(0, 5).ToUpper(), s.StudentId, s._selectedCourses);
//                        demoReq.Submit();
//                        requests.Add(demoReq);
//                        s.ViewEnrolledList();

//                        s.SubmitEnrolment(audit);                        

//                        Console.WriteLine("\nEnrolment sent to Registry successfully!");
//                    }
//                    else if (choice == "2")
//                    {
//                        Console.WriteLine();
//                        s.ViewEnrolledList();
//                        choice = "1";
//                    }
//                    else choice = "2";
//                }                
//            }
//        }
//        else Console.WriteLine("Login Failed.");

//        Console.WriteLine("\nPress Enter to return...");
//        Console.ReadLine();
//    }

//    // --- STAFF INTERACTIVE FLOW ---
//    static void HandleStaffFlow(RegistryStaff staff, Student s, AuditService audit, List<EnrolmentRequest> requests)
//    {
//        Console.WriteLine("\n--- REGISTRY PORTAL ---");
//        Console.Write("Username: ");
//        string username = Console.ReadLine();
//        Console.Write("Password: ");
//        string password = Console.ReadLine();

//        if (username == staff.Username)
//        {
//            staff.Login(username, password, audit);            
//            string choice = "1";
//            while (choice != "3")
//            {
//                Console.WriteLine("\n1. Monitor All Enrolments");
//                Console.WriteLine("2. Approve Pending Requests");
//                Console.WriteLine("3. Logout");
//                Console.Write("Choice: ");
//                choice = Console.ReadLine();
//                if (choice == "1") staff.MonitorEnrolments(requests);
//                if (choice == "2" && requests.Count > 0)
//                {
//                    staff.ReviewEnrolmentRequest(s, requests[0]);
//                    staff.ApproveEnrolment(requests[0], audit);
//                }
//                else if (choice == "2") { Console.WriteLine("No pending requests to approve."); }
//            }
//        }
//        else { Console.WriteLine("Login Failed."); }
//        Console.WriteLine("\nPress Enter to return to main menu...");
//        Console.ReadLine();
//    }
//}

//public class MockAUTSystem : ICourseInfoSystem
//{
//    // When a student searches, this prints a fake database response
//    public void GetCourseInfo(string criteria)
//    {
//        Console.WriteLine("[DATABASE] Fetching courses for your programme...");
//        Console.WriteLine(" > Found: ENSE706, COMP603, ENSE602");
//    }

//    public void UpdateCourse(string courseId) { }
//}
using System;

class Program
{
    static void Main(string[] args)
    {
        IAuthSystem authSystem = new UserAdapter();
        AuthService authService = new AuthService(authSystem);

        while (true)
        {
            Console.WriteLine("\n----- LOGIN SYSTEM -----");

            Console.Write("Username: ");
            string username = Console.ReadLine();

            Console.Write("Password: ");
            string password = Console.ReadLine();

            User user = authService.Login(username, password);

            if (user == null)
            {
                Console.WriteLine("Login failed.");
                continue;
            }

            Console.WriteLine("Login successful!");

            if (user is Student student)
            {
                StudentMenu(student);
            }
            else if (user is RegistryStaff registry)
            {
                RegistryMenu(registry);
            }

            // after logout → loop returns here (back to login screen)
        }
    }
    static void StudentMenu(Student student)
    {
        CourseService courseService =
            new CourseService(new CourseInfoAdapter());

        ValidationService validationService =
            new ValidationService();

        while (true)
        {
            Console.WriteLine("\n----- STUDENT MENU -----");
            Console.WriteLine("1. Search Courses");
            Console.WriteLine("2. View Course Details");
            Console.WriteLine("3. Select Course");
            Console.WriteLine("4. View Selected Courses");
            Console.WriteLine("5. Submit Enrolment");
            Console.WriteLine("6. View Enrolment Status");
            Console.WriteLine("0. Logout");

            Console.Write("Choose: ");
            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    student.SearchCourses(courseService);
                    break;

                case "2":
                    Console.Write("Enter course code: ");
                    string code = Console.ReadLine();

                    student.ViewCourseDetails(courseService, code);
                    break;

                case "3":
                    Console.Write("Enter course code: ");
                    string c = Console.ReadLine();

                    Course course = courseService.GetCourse(c);

                    if (course != null)
                    {
                        student.SelectCourse(course, validationService);
                    }
                    else
                    {
                        Console.WriteLine("Course not found.");
                    }
                    break;

                case "4":
                    student.ViewEnrolledList();
                    break;

                case "5":
                    student.SubmitEnrolment();
                    break;

                case "6":
                    student.ViewEnrolmentStatus();
                    break;

                case "0":
                    Console.WriteLine("Logging out...");
                    return; // goes back to login screen

                default:
                    Console.WriteLine("Invalid option");
                    break;
            }
        }
    }

    static void RegistryMenu(RegistryStaff staff)
    {
        IFinanceSystem financeSystem = new FinanceSystemAdapter();
        FinanceService financeService = new FinanceService(financeSystem);
        EnrolmentService enrolmentService = new EnrolmentService(
            new ValidationService(),
            new FinanceService(new FinanceSystemAdapter()),
            new NotificationService()
        );

        NotificationService notificationService = new NotificationService();

        while (true)
        {
            Console.WriteLine("\n----- REGISTRY MENU -----");
            Console.WriteLine("1. Monitor Enrolments");
            Console.WriteLine("2. Review Enrolment Request");
            Console.WriteLine("3. Check Student Eligibility");
            Console.WriteLine("4. Approve Request");
            Console.WriteLine("5. Reject Request");
            Console.WriteLine("0. Logout");

            Console.Write("Choose: ");
            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    staff.MonitorEnrolments();
                    break;

                case "2":
                    Console.Write("Enter Request ID: ");
                    string rid = Console.ReadLine();
                    staff.ReviewEnrolmentRequest(rid);
                    break;

                case "3":
                    Console.Write("Enter Request ID: ");
                    string idCheck = Console.ReadLine();
                    staff.CheckStudentEligibility(
                        "S000001",
                        financeService
                    );
                    break;

                case "4":
                    Console.Write("Enter Request ID: ");
                    string approveId = Console.ReadLine();

                    staff.ApproveEnrolment(
                        approveId,
                        notificationService
                    );
                    break;

                case "5":
                    Console.Write("Enter Request ID: ");
                    string rejectId = Console.ReadLine();

                    staff.RejectEnrolment(
                        rejectId,
                        notificationService
                    );
                    break;

                case "0":
                    return;

                default:
                    Console.WriteLine("Invalid option");
                    break;
            }
        }
    }
}