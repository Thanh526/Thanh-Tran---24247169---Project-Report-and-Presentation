﻿public abstract class User
{
    public string UserId { get; private set; }
    public string Username { get; set; }
    private string _password;
    public string Name { get; set; }
    public string Email { get; set; }
    public string Address { get; set; }

    public void Login() { }
    public void Logout() { }
    public void ResetPassword() { }
}