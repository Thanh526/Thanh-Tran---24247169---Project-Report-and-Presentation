﻿using System;

public abstract class User
{
    public string UserId { get; private set; }
    public string Username { get; set; }
    private string _password;

    public User(string userId, string username, string password)
    {
        UserId = userId;
        Username = username;
        _password = password;
    }

    public void Login(string username, string password, AuditService audit)
    {
        if (Username == username && _password == password)
        {
            audit.LogActivity(this.UserId, "Successful login", DateTime.Now);
            Console.WriteLine($"{Username} logged in successfully.");
        }
        else
        {
            audit.LogActivity(this.UserId ?? username, "Failed login", DateTime.Now);
            Console.WriteLine("Login failed. Invalid credentials.");
        }
    }

    public void Logout(AuditService audit)
    {
        audit.LogActivity(this.UserId, "User logout", DateTime.Now);

        Console.WriteLine($"Session ended for {Username}.");
        Console.WriteLine($"You have been successfully logged out.");
    }

    public void ResetPassword(string oldPassword, string newPassword)
    {
        if (_password == oldPassword)
        {
            _password = newPassword;
            Console.WriteLine("Password updated successfully.");
        }
        else
        {
            Console.WriteLine("Verification failed. Password not changed.");
        }
    }
}