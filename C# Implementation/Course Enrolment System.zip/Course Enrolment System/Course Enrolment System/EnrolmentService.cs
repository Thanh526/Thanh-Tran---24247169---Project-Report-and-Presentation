﻿public class EnrolmentService
{
    public void ConfirmEnrolment() { }
}