﻿public class EnrolmentService
{
    public void CheckFinancialEligibility(string studentId, StudentType type) { }
    public void ValidatePrerequisites() { }
    public void CheckCourseCapacity() { }
    public void DetectTimetableClashes() { }
    public void ConfirmEnrolment() { }
}