﻿public enum EnrolmentStatus
{
    Draft,
    Pending,
    Approved,
    Rejected,
    Confirmed
}