﻿public interface ICourseInfoSystem
{
    Course GetCourseInfo(string courseCode);
    bool CheckCourseAvailability(string courseCode);
}