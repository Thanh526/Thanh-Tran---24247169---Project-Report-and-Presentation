﻿// Defines the interface for accessing course information.
// Provides a common contract for retrieving course details, listing available courses, and checking course availability.
// Used to integrate LegacyCourseSystem through the Adapter Pattern.
public interface ICourseInfoSystem
{
    List<Course> GetAllCourses();
    Course GetCourseInfo(string courseCode);
    bool CheckCourseAvailability(string courseCode);
}