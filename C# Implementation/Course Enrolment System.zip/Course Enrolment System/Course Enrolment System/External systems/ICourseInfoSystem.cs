﻿public interface ICourseInfoSystem
{
    List<Course> GetAllCourses();
    Course GetCourseInfo(string courseCode);
    bool CheckCourseAvailability(string courseCode);
}