﻿// Mock classes for return types used in interfaces
public class CourseData { }
public class AcademicRecord { }
public class Transcript { }
public class PaymentData { }
public class PaymentStatus { }


/// <summary>
/// Adaptees (Legacy External Subsystems)
/// </summary>

// Legacy External System 1
public class LegacyCourseSystem
{
    public CourseData FetchCourse(string code) => new CourseData();
    public bool IsFull(string code) => true;
}
// Legacy External System 2
public class LegacyStudentSystem
{
    public Transcript FetchTranscript(string id) => new Transcript();
}
// Legacy External System 3
public class LegacyFinanceSystem
{
    public PaymentData GetOldPayments(string accountNo) => new PaymentData();
    public bool CheckOldInsurance(string policyId) => true;
}
// Legacy External System 3
public class LegacyHRSystem
{
    public string FetchRole(string empId) => "Lecturer";
}

/// <summary>
/// Adapters
/// </summary>

// Adapter 1: Course Info
public class CourseInfoAdapter : ICourseInfoSystem
{
    private LegacyCourseSystem legacyCourseSystem;

    public CourseInfoAdapter() => legacyCourseSystem = new LegacyCourseSystem();

    public Course GetCourseInfo(string courseCode)
    {
        CourseData courseData = legacyCourseSystem.FetchCourse(courseCode);
        return new Course();
    }
    public bool CheckCourseAvailability(string courseCode) => !legacyCourseSystem.IsFull(courseCode);
}
// Adapter 2: Student Info
public class StudentInfoAdapter : IStudentInfoSystem
{
    private LegacyStudentSystem legacyStudentSystem;

    public StudentInfoAdapter() => legacyStudentSystem = new LegacyStudentSystem();

    public AcademicRecord GetAcademicRecord(string studentId)
    {
        Transcript transcript = legacyStudentSystem.FetchTranscript(studentId);

        return new AcademicRecord();
    }
}
// Adapter 3: Finance
public class FinanceSystemAdapter : IFinanceSystem
{
    private LegacyFinanceSystem legacyFinanceSystem;

    public FinanceSystemAdapter() => legacyFinanceSystem = new LegacyFinanceSystem();

    public PaymentStatus GetPaymentStatus(string studentId)
    {
        string accountNo = ConvertStudentIdToAccountNo(studentId);

        PaymentData payment = legacyFinanceSystem.GetOldPayments(accountNo);

        return new PaymentStatus();
    }
    public bool VerifyInsurance(string studentId)
    {
        string policyId = ConvertStudentIdToPolicyId(studentId);
        return legacyFinanceSystem.CheckOldInsurance(policyId);
    }
    private string ConvertStudentIdToAccountNo(string studentId) => "ACC-" + studentId;
    private string ConvertStudentIdToPolicyId(string studentId) => "POL-" + studentId;
}
// Adapter 4: HR
public class HRSystemAdapter : IHRSystem
{
    private LegacyHRSystem legacyHRSystem;

    public HRSystemAdapter() => legacyHRSystem = new LegacyHRSystem();

    public string GetStaffRole(string staffId) => legacyHRSystem.FetchRole(staffId);
}