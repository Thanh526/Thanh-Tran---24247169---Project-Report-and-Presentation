﻿public interface IStudentInfoSystem
{
    AcademicRecord GetAcademicRecord(string studentId);
}