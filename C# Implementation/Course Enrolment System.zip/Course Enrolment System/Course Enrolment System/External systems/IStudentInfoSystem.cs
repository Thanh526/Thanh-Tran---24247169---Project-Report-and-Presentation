﻿// Defines the interface for accessing student information.
// Provides a common contract for retrieving student details and academic records from an external student information system.
// Used to integrate LegacyStudentSystem through the Adapter Pattern.
public interface IStudentInfoSystem
{
    Student GetStudentInfo(string studentId);
    AcademicRecord GetAcademicRecord(string studentId);
}