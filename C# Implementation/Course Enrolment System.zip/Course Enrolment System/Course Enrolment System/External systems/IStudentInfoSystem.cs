﻿public interface IStudentInfoSystem
{
    Student GetStudentInfo(string studentId);
    AcademicRecord GetAcademicRecord(string studentId);
}