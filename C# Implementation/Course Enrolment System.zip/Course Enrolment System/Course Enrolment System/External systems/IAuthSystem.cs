﻿public interface IAuthSystem
{
    UserData ValidateLogin(string username, string password);
}