﻿// Defines the authentication interface for validating user login credentials.
// Provides a common contract for external authentication systems,
// allowing the Course Enrolment System to authenticate users
// without depending directly on LegacyUserSystem
public interface IAuthSystem
{
    UserData ValidateLogin(string username, string password);
}