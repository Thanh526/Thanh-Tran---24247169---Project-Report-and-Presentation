﻿public interface IHRSystem
{
    string GetStaffRole(string staffId);
}