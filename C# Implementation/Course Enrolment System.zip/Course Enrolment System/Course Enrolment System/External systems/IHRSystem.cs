﻿// Defines the interface for accessing staff information.
// Provides a common contract for retrieving staff roles from an external Human Resource (HR) system.
// Used to integrate LegacyHRSystem through the Adapter Pattern.
public interface IHRSystem
{
    string GetStaffRole(string staffId);
}