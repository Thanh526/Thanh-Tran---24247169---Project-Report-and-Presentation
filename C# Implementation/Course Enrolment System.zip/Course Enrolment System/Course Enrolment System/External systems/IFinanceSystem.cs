﻿public interface IFinanceSystem
{
    PaymentStatus GetPaymentStatus(string studentId);
    bool VerifyInsurance(string studentId);
}