﻿// Defines the interface for accessing student financial information.
// Provides a common contract for retrieving payment status and verifying insurance requirements.
// Used to integrate LegacyFinanceSystem through the Adapter Pattern.
public interface IFinanceSystem
{
    PaymentStatus GetPaymentStatus(string studentId);
    bool VerifyInsurance(string studentId);
}
