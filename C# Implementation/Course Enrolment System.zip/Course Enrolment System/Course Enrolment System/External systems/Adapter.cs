﻿/// <summary>
/// Store adapter and adaptee of adapter pattern
/// <summary>



/// <summary>
/// Adaptees (Legacy External Subsystems)
/// </summary>

// Legacy External System 1
public class LegacyCourseSystem
{
    private Dictionary<string, CourseData> _courses = new();
    
    // Mock data
    public LegacyCourseSystem()
    {
        _courses["ENSE706"] = new CourseData(
            "ENSE706",
            "Data Process and Software Modelling",
            "This course introduces the Unified Modeling Language (UML) as a key tool for requirements analysis, object-oriented software design, and identifying use cases.",
            new List<string>() { "ENSE602" },
            20,
            15
        );

        _courses["COMP716"] = new CourseData(
            "COMP716",
            "Highly Secure Systems",
            "This course introduces the concepts and principles of modern cryptography to use them for key exchange, encryption, authentication, protection of data integrity,and enabling non-repudiation",
            new List<string> { "ENGE501", "COMP610" },
            40,
            15
        );

        _courses["COMP721"] = new CourseData(
            "COMP721",
            "Web Development",
            "This course introduces the knowledge of data communications and internetworking over the World Wide Web, to cover issues associated with development of applications in this environment",
            new List<string> { "COMP603" },
            100,
            15
        );
    }

    // Get all courses from external system
    public List<CourseData> FetchAllCourses()
    {
        return _courses.Values.ToList();
    }

    public CourseData FetchCourse(string code)
    {
        return _courses.ContainsKey(code) ? _courses[code] : null;
    }

    public bool IsFull(string code)
    {
        if (!_courses.ContainsKey(code))
            return true;

        return _courses[code].Capacity <= 0;
    }
}

// Legacy External System 2
public class LegacyStudentSystem
{
    public Transcript FetchTranscript(string id)
    {
        if (id == "S000001")
        {
            return new Transcript
            {
                StudentId = "S000001",
                Programme = "Software Engineering",
                StudentType = StudentType.International,
                GPA = 3.6,
                FinishedCourses = new List<string> { "ENGE501", "ENSE602", "COMP610" },

                CourseResults = new List<CourseResult> { }
            };
        }
        return null;
    }
}
// Legacy External System 3
public class LegacyFinanceSystem
{
    // Mock payment data
    public PaymentData GetOldPayments(string accountNo)
    {
        return new PaymentData
        {
            AccountNo = accountNo,
            PaidAmount = 4500,
            OutstandingAmount = 0,
            Status = "Partial"
        };
    }

    // Mock insurance check
    public bool CheckOldInsurance(string policyId)
    {
        return policyId == "POL-S000001";
    }
}
// Legacy External System 4
public class LegacyHRSystem
{
    // Mock data
    public string FetchRole(string empId) => "Lecturer";
}

// Legacy External System 5
public class LegacyUserSystem
{
    // Validate login and return basic user identity data
    public UserData ValidateLogin(string username, string password)
    {
        // Mock Student account
        if (username == "student1" && password == "123")
        {
            return new UserData { UserId = "S000001", Username = username, Role = "Student" };
        }

        // Mock RegistryStaff account
        if (username == "staff1" && password == "abc")
        {
            return new UserData { UserId = "ST000001", Username = username, Role = "RegistryStaff" };
        }

        // Mock AcademicStaff account
        if (username == "staff2" && password == "456")
        {
            return new UserData { UserId = "ST000002", Username = username, Role = "AcademicStaff" };
        }
        // Invalid login
        return null;
    }
}

/// <summary>
/// Adapters
/// </summary>

// Adapter 1: Course Info
public class CourseInfoAdapter : ICourseInfoSystem
{
    private LegacyCourseSystem legacyCourseSystem;

    public CourseInfoAdapter() => legacyCourseSystem = new LegacyCourseSystem();

    // Get all courses
    public List<Course> GetAllCourses()
    {
        List<Course> courses = new List<Course>();

        List<CourseData> allCourseData = legacyCourseSystem.FetchAllCourses();

        foreach (var data in allCourseData)
        {
            Course course = new Course(
                data.CourseCode,
                data.CourseName,
                data.Capacity,
                data.Credits
            );

            course.SetDescription(data.Description);

            foreach (var pre in data.Prerequisites)
            {
                course.AddPrerequisites(new Course(pre));
            }

            courses.Add(course);
        }

        return courses;
    }

    public Course GetCourseInfo(string courseCode)
    {
        CourseData data = legacyCourseSystem.FetchCourse(courseCode);

        if (data == null)
            return null;

        Course course = new Course(data.CourseCode, data.CourseName, data.Capacity, data.Credits);
        course.SetDescription(data.Description);

        foreach (var pre in data.Prerequisites)
        {
            course.AddPrerequisites(new Course(pre));
        }

        return course;
    }

    public bool CheckCourseAvailability(string courseCode) => !legacyCourseSystem.IsFull(courseCode);
}
// Adapter 2: Student Info
public class StudentInfoAdapter : IStudentInfoSystem
{
    private LegacyStudentSystem legacyStudentSystem;

    public StudentInfoAdapter() => legacyStudentSystem = new LegacyStudentSystem();

    public Student GetStudentInfo(string studentId)
    {
        var transcript = legacyStudentSystem.FetchTranscript(studentId);

        Student student = new Student(studentId, "", "");
        student.SetStudentType(transcript.StudentType);
        student.SetProgramme(transcript.Programme);
        return student;
    }

    public AcademicRecord GetAcademicRecord(string studentId)
    {
        Transcript transcript = legacyStudentSystem.FetchTranscript(studentId);

        return new AcademicRecord
        {
            StudentId = transcript.StudentId,
            Programme = transcript.Programme,
            StudentType = transcript.StudentType,
            FinishedCourses = transcript.FinishedCourses,
            CourseResults = transcript.CourseResults,
            GPA = transcript.GPA
        };
    }
}
// Adapter 3: Finance
public class FinanceSystemAdapter : IFinanceSystem
{
    private readonly LegacyFinanceSystem legacyFinanceSystem;

    public FinanceSystemAdapter()
    {
        legacyFinanceSystem = new LegacyFinanceSystem();
    }

    // Convert legacy payment data into internal PaymentStatus
    public PaymentStatus GetPaymentStatus(string studentId)
    {
        string accountNo = ConvertStudentIdToAccountNo(studentId);

        PaymentData legacyData = legacyFinanceSystem.GetOldPayments(accountNo);

        return new PaymentStatus
        {
            PaidAmount = legacyData.PaidAmount,
            OutstandingAmount = legacyData.OutstandingAmount,
            Status = legacyData.Status
        };
    }

    // Direct mapping from insurance check
    public bool VerifyInsurance(string studentId)
    {
        string policyId = ConvertStudentIdToPolicyId(studentId);

        return legacyFinanceSystem.CheckOldInsurance(policyId);
    }

    // Helper conversion methods
    private string ConvertStudentIdToAccountNo(string studentId) => "ACC-" + studentId;
    private string ConvertStudentIdToPolicyId(string studentId)=> "POL-" + studentId;
}
// Adapter 4: HR
public class HRSystemAdapter : IHRSystem
{
    private LegacyHRSystem legacyHRSystem;

    public HRSystemAdapter() => legacyHRSystem = new LegacyHRSystem();

    public string GetStaffRole(string staffId) => legacyHRSystem.FetchRole(staffId);
}

// Adapter 5: User
public class UserAdapter : IAuthSystem
{
    private readonly LegacyUserSystem _legacy;

    public UserAdapter()
    {
        _legacy = new LegacyUserSystem();
    }

    public UserData ValidateLogin(string username, string password)
    {
        return _legacy.ValidateLogin(username, password);
    }
}

/// <summary>
/// Mock classes for return types used in interfaces
/// </summary>
public class CourseData
{
    public string CourseCode { get; private set; }
    public string CourseName { get; private set; }
    public string Description { get; private set; }

    public List<string> Prerequisites { get; private set; }
    public int Capacity { get; private set; }
    public int Credits { get; private set; }

    public CourseData(string code, string name, string description,
                      List<string> prerequisites, int capacity, int credits)
    {
        CourseCode = code;
        CourseName = name;
        Description = description;
        Prerequisites = prerequisites;
        Capacity = capacity;
        Credits = credits;
    }
}

public class AcademicRecord
{
    public string StudentId { get; set; }
    public string Programme { get; set; }
    public StudentType StudentType { get; set; }
    public List<string> FinishedCourses { get; set; } = new List<string>();

    public List<CourseResult> CourseResults { get; set; } = new List<CourseResult>();
    public double GPA { get; set; }

    // Add course result to record
    public void AddCourseResult(CourseResult result)
    {
        CourseResults.Add(result);
    }

    // Update GPA
    public void UpdateGPA(double newGPA)
    {
        GPA = newGPA;
    }
}

public class Transcript
{
    public string StudentId { get; set; }
    public string Programme { get; set; }
    public StudentType StudentType { get; set; }
    public List<string> FinishedCourses { get; set; } = new List<string>();

    public List<CourseResult> CourseResults { get; set; } = new List<CourseResult>();
    public double GPA { get; set; }

    // Add a course result to transcript
    public void AddCourseResult(CourseResult result)
    {
        CourseResults.Add(result);
    }
}
public class CourseResult { }
public class PaymentData
{
    public string AccountNo { get; set; }
    public double PaidAmount { get; set; }
    public double OutstandingAmount { get; set; }
    public string Status { get; set; }
}
public class PaymentStatus
{
    public double PaidAmount { get; set; }
    public double OutstandingAmount { get; set; }
    public string Status { get; set; }
}

// Represents basic user information returned from external authentication system
public class UserData
{
    public string UserId { get; set; }
    public string Username { get; set; }
    public string Role { get; set; } // Student / AcademicStaff / SystemAdmin
}