﻿// Represents a Course entity in the Course Enrolment System.
// Stores core course information such as code, name, description,
// credits, capacity, and prerequisites.
// Provides operations for enrolment management and course updates.
public class Course
{
    public string CourseCode { get; init; }
    public string CourseName { get; private set; }
    public string Description { get; private set; }
    public List<Course> Prerequisites { get; private set; } = new List<Course>();
    public int Capacity { get; private set; }
    public int Credits { get; private set; }

    // Constructor
    public Course(string code, string name, int cap, int credits)
    {
        CourseCode = code;
        CourseName = name;
        Capacity = cap;
        Credits = credits;
    }
    public Course(string code) => CourseCode = code;

    // Updates course name
    public void SetCourseName(string name) => CourseName = name;
    // Updates course description
    public void SetDescription(string newDescription) => Description = newDescription;
    // Updates course credit value
    public void UpdateCredits(int newCredits) => Credits = newCredits;
    // Checks if course still has available capacity
    public bool IsAvailable() => Capacity > 0;
    // Rreduces capacity by 1 if a student enrols in
    public void StudentEnrolment()
    {
        if (Capacity > 0)
        {
            Capacity--;
        }
    }
    // Increases capacity by 1 if a student cancels enrolment
    public void CancelEnrolment()
    {
        Capacity++;
    }
    // Adds prerequisite courses
    public void AddPrerequisites(params Course[] courses)
    {
        Prerequisites.AddRange(courses);
    }
    // Removes prerequisite courses
    public void RemovePrerequisite(params Course[] courses) {
        foreach (var course in courses)
        {
            Prerequisites.Remove(course);
        }
    }
    // Updates capacity
    public void UpdateCapacity(int amount)
    {
        if (Capacity + amount < 0)
        {
            Console.WriteLine("Error: Decrease amount cannot be larger than the current remaining capacity.");
            return;
        }

        Capacity += amount;
    }
}