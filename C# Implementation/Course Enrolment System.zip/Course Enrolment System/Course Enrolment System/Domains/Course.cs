﻿using System;
using System.Collections.Generic;

public class Course
{
    public string CourseCode { get; init; }
    public string CourseName { get; init; }
    public string Description { get; private set; }
    public List<Course> Prerequisites { get; private set; } = new List<Course>();
    public int Capacity { get; private set; }
    public int Credits { get; private set; }

    // Constructor
    public Course(string code, string name, int cap, int credits)
    {
        CourseCode = code;
        CourseName = name;
        Capacity = cap;
        Credits = credits;
    }

    public void SetDescription(string newDescription) => Description = newDescription;
    public void UpdateCredits(int newCredits) => Credits = newCredits;
    public bool IsAvailable() => Capacity > 0;
    public void Enrol()
    {
        if (Capacity > 0)
        {
            Capacity--;
        }
    }
    public void CancelEnrolment()
    {
        Capacity++;
    }
    public void AddPrerequisites(params Course[] courses)
    {
        Prerequisites.AddRange(courses);
    }
    public void UpdateCapacity(int amount)
    {
        if (Capacity + amount < 0)
        {
            Console.WriteLine("Error: Decrease amount cannot be larger than the current remaining capacity.");
            return;
        }

        Capacity += amount;
    }
    public void RemovePrerequisite(params Course[] courses) {
        foreach (var course in courses)
        {
            Prerequisites.Remove(course);
        }
    }
}