﻿public static class EnrolmentRepository
{
    private static List<EnrolmentRequest> _requests
        = new List<EnrolmentRequest>();

    public static void Add(EnrolmentRequest request)
    {
        _requests.Add(request);
    }

    public static List<EnrolmentRequest> GetAll()
    {
        return _requests;
    }
}