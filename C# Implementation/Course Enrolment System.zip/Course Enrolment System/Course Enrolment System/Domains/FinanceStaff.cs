﻿public class FinanceStaff : Staff
{
    public string FinanceUnit { get; set; }

    public FinanceStaff(string username, string password, string dept, string financeUnit)
        : base(username, password, dept)
    {
        this.FinanceUnit = financeUnit;
    }
    public void ViewPaymentStatus() { }
    public void HandlePaymentException()
    {
        Console.WriteLine("Opening Finance System for handling payment exception");
    }
}