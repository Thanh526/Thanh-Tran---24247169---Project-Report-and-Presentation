﻿// Represents a System Administrator responsible for managing user access, system configuration, and reviewing audit logs.
public class SystemAdmin : Staff
{
    public string AdminLevel { get; set; }

    // Constructor
    public SystemAdmin(string username, string password, string dept, string adminLevel)
        : base(username, password, dept)
    {
        this.AdminLevel = adminLevel;
    }

    // Allows or blocks a user's login access
    public void ManageUserAccess(User user, bool isAllowed)
    {
        user.SetAccess(this, isAllowed);

        AuditService.Instance.LogActivity(
            _userID,
            isAllowed
                ? $"Granted login access to {user.Username}"
                : $"Revoked login access from {user.Username}",
            DateTime.Now);

        Console.WriteLine($"Access updated for {user.Username}");
    }

    // Configure system settings
    public void SetSystemConfiguration()
    {
        AuditService.Instance.LogActivity(_userID, "Updated system configuration", DateTime.Now);
    }

    // Review system audit logs
    public void ReviewAuditLogs()
    {
        AuditService.Instance.ViewAuditLogs();
    }
}