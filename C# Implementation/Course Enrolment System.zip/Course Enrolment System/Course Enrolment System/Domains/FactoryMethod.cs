﻿// Contains the Factory Method implementation for User creation.
// Includes the Abstract Creator (UserCreator) which defines the factory
// method, and Concrete Creator classes that instantiate specific User types.

// Abstract Creator
abstract class UserCreator
{
    // The Factory Method
    public abstract User CreateUser(string username, string password, string param1, string param2);
}

// Concrete Creators matching each Concrete Product 1-to-1
class StudentCreator : UserCreator
{
    public override User CreateUser(string username, string password, string programme, string studentType)
    {
        return new Student(username, password, programme, studentType);
    }
}

class AcademicStaffCreator : UserCreator
{
    public override User CreateUser(string username, string password, string dept, string faculty)
    {
        return new AcademicStaff(username, password, dept, faculty);
    }
}

class RegistryStaffCreator : UserCreator
{
    public override User CreateUser(string username, string password, string dept, string office)
    {
        return new RegistryStaff(username, password, dept, office);
    }
}

class FinanceStaffCreator : UserCreator
{
    public override User CreateUser(string username, string password, string dept, string financeUnit)
    {
        return new FinanceStaff(username, password, dept, financeUnit);
    }
}

class ITStaffCreator : UserCreator
{
    public override User CreateUser(string username, string password, string dept, string technicalArea)
    {
        return new ITStaff(username, password, dept, technicalArea);
    }
}

class SystemAdminCreator : UserCreator
{
    public override User CreateUser(string username, string password, string dept, string adminLevel)
    {
        return new SystemAdmin(username, password, dept, adminLevel);
    }
}