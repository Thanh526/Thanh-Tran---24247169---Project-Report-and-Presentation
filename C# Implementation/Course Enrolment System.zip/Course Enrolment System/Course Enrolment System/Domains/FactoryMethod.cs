﻿// Contains the Factory Method implementation for User creation.
// Includes the Abstract Creator (UserCreator) which defines the factory
// method, and Concrete Creator classes that instantiate specific User types.

// Abstract Creator
abstract class UserCreator
{
    // The Factory Method
    public abstract User CreateUser(string userID, string username, string password);
}

// Concrete Creators matching each Concrete Product 1-to-1
class StudentCreator : UserCreator
{
    public override User CreateUser(string userID, string username, string password)
    {
        return new Student(userID, username, password);
    }
}

class AcademicStaffCreator : UserCreator
{
    public override User CreateUser(string userID, string username, string password)
    {
        return new AcademicStaff(userID, username, password);
    }
}

class RegistryStaffCreator : UserCreator
{
    public override User CreateUser(string userID, string username, string password)
    {
        return new RegistryStaff(userID, username, password);
    }
}

class FinanceStaffCreator : UserCreator
{
    public override User CreateUser(string userID, string username, string password)
    {
        return new FinanceStaff(userID, username, password);
    }
}

class ITStaffCreator : UserCreator
{
    public override User CreateUser(string userID, string username, string password)
    {
        return new ITStaff(userID, username, password);
    }
}

class SystemAdminCreator : UserCreator
{
    public override User CreateUser(string userID, string username, string password)
    {
        return new SystemAdmin(userID, username, password);
    }
}