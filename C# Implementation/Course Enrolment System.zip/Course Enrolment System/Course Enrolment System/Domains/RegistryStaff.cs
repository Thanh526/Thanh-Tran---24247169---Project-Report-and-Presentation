﻿using System;
using System.Collections.Generic;
using System.Linq;

public class RegistryStaff : Staff
{
    public string OfficeLocation { get; set; }

    public RegistryStaff(string username, string password, string dept, string office)
        : base(username, password, dept)
    {
        this.OfficeLocation = office;
    }

    public void MonitorEnrolments(List<EnrolmentRequest> allRequests)
    {
        Console.WriteLine($"--- Enrolment monitoring ---");

        int pendingCount = 0;
        foreach (var req in allRequests)
        {
            if (req.EnrolmentStatus == EnrolmentStatus.Pending) pendingCount++;
        }

        Console.WriteLine($"Total requests: {allRequests.Count}");
        Console.WriteLine($"Action required (pending): {pendingCount}");
        Console.WriteLine("\n--- Enrolment request list ---");

        foreach (var req in allRequests)
        {
            var courseCodes = string.Join(", ", req.GetRequestedCourses().Select(c => c.CourseCode));

            Console.WriteLine($"Request ID: {req.RequestId}, " +
                              $"Student: {req.StudentId}, " +
                              $"Courses: [{courseCodes}], " +
                              $"Status: {req.EnrolmentStatus}");
        }
        Console.WriteLine("\n--------------------------------------------------");
    }
    public void ReviewEnrolmentRequest(Student student, EnrolmentRequest request)
    {
        Console.WriteLine($"Staff {this.Username} is reviewing Request: {request.RequestId}");
        Console.WriteLine($"Student: {student.Username} ({student.StudentId})");
        Console.WriteLine($"Programme: {student.Programme}");
        Console.WriteLine($"Submission Date: {request.SubmissionDate.ToLongDateString()}");
        Console.WriteLine($"Current Status: {request.EnrolmentStatus}");

        Console.WriteLine("System Note: Student has met basic financial eligibility.");
        Console.WriteLine("\n--------------------------------------------------");
    }
    public bool CheckStudentEligibility(Student student, IStudentInfoSystem sis, IFinanceSystem fis)
    {
        Console.WriteLine($"Running verification for: {student.Username} ({student.StudentId})");

        Console.WriteLine("Step 1: Fetching academic records from SIS...");
        sis.GetAcademicRecord(student.StudentId);

        Console.WriteLine("Step 2: Verifying outstanding fees and insurance...");
        fis.GetPaymentStatus(student.StudentId);
        fis.VerifyInsurance(student.StudentId);

        bool isEligible = true;

        if (isEligible)
        {
            Console.WriteLine("Student is eligibility for enrolment.");
            return true;
        }
        else
        {
            Console.WriteLine("Student is ineligibility due to outstanding requirements.");
            return false;
        }
    }
    public void ApproveEnrolment(EnrolmentRequest request, AuditService audit)
    {
        if (request.EnrolmentStatus == EnrolmentStatus.Pending)
        {
            request.SetStatus(EnrolmentStatus.Approved);

            audit.LogActivity(this.UserId, $"Approved enrolment {request.RequestId}", DateTime.Now);

            Console.WriteLine($"Request {request.RequestId} has been approved by {this.Username}.");
        }
        else
        {
            Console.WriteLine($"Cannot approve: Request is in {request.EnrolmentStatus} state.");
        }
    }
    public void RejectEnrolment(EnrolmentRequest request, string reason, AuditService audit)
    {
        request.SetStatus(EnrolmentStatus.Rejected);

        audit.LogActivity(this.UserId, $"Rejected enrolment {request.RequestId}. Reason: {reason}", DateTime.Now);

        Console.WriteLine($"Request {request.RequestId} has been rejected. Reason: {reason}");
    }
}