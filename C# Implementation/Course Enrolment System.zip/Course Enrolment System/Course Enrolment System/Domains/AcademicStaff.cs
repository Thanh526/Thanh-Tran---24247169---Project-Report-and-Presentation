﻿public class AcademicStaff : Staff
{
    public string Faculty { get; set; }

    public AcademicStaff(string username, string password, string dept, string faculty)
        : base(username, password, dept)
    {
        this.Faculty = faculty;
    }
    public void ViewCoursDetails(Course course)
    {
        Console.WriteLine("-------------- Course details ---------------");
        Console.WriteLine($"Code: {course.CourseCode}");
        Console.WriteLine($"Name: {course.CourseName}");
        Console.WriteLine($"Description: {course.Description}");
        Console.WriteLine($"Credits: {course.Credits}");
        Console.WriteLine($"Current Capacity: {course.Capacity}");

        Console.Write("Prerequisites: ");
        if (course.Prerequisites.Count == 0) Console.Write("None");
        else Console.Write(string.Join(", ", course.Prerequisites.Select(p => p.CourseCode)));
        Console.WriteLine("\n------------------------------------------");
    }
    public void ManageCourse() 
    {
        Console.WriteLine("Opening Course System for managing course");
    }
    public void GrantOverride()
    {
        Console.WriteLine("Opening Course System for granting override");
    }
}