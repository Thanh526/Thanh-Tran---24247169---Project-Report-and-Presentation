﻿public abstract class Staff : User
{
    private static int _staffCounter = 0; // Used to generate sequential staff IDs
    private string _staffID { get; init; }
    public string Department { get; set; }

    public Staff(string username, string password, string dept)
        : base(username, password)
    {
        this._staffID = _staffCounter.ToString("D4"); // 4-digit format
        this.Department = dept;
    }
}