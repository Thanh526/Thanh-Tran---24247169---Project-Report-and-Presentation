﻿using System;
using System.Collections.Generic;
using System.Net.NetworkInformation;

public class EnrolmentRequest
{
    private static int _requestCounter = 0; // Used to generate sequential request IDs
    private string _requestId { get; init; } = "R" + (_requestCounter++).ToString("D8"); // Unique 8-digit format Request ID 
    public string StudentId { get; private set; }
    public DateTime SubmissionDate { get; init; } = DateTime.Now;
    public EnrolmentStatus _enrolmentStatus { get; private set; } = EnrolmentStatus.Draft;
    private List<Course> _enrolmentCourses { get; set; } = new List<Course>();

    public EnrolmentRequest(string studentId)
    {
        StudentId = studentId;
    }

    public string GetRequestID() {  return _requestId; }
    public void SetCourses(List<Course> courses)
    {
        _enrolmentCourses = new List<Course>(courses);
    }
    public List<Course> GetCourses()
    {
        return _enrolmentCourses;
    }
    public void Submit() { _enrolmentStatus = EnrolmentStatus.Pending; }
    public void Cancel() { _enrolmentStatus = EnrolmentStatus.Rejected; }
    public void Resubmit() { _enrolmentStatus = EnrolmentStatus.Pending; }
    public void Approve() { _enrolmentStatus = EnrolmentStatus.Approved; }
    public void Reject() { _enrolmentStatus = EnrolmentStatus.Rejected; }

    // View request details
    public void GetEnrolmentRequestDetails()
    {
        Console.WriteLine($"Request ID: {_requestId}");
        Console.WriteLine($"Status: {_enrolmentStatus}");

        foreach (var c in _enrolmentCourses)
        {
            Console.WriteLine($"- {c.CourseCode}");
        }
    }

    // Getter for status
    public EnrolmentStatus GetStatus()
    {
        return _enrolmentStatus;
    }
}