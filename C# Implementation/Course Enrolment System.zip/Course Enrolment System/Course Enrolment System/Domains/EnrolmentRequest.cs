﻿using System;
using System.Collections.Generic;

public class EnrolmentRequest
{
    private string _requestId { get; init; } = Guid.NewGuid().ToString().Substring(0, 8);
    public DateTime SubmissionDate { get; init; } = DateTime.Now;
    private EnrolmentStatus _enrolmentStatus { get; set; } = EnrolmentStatus.Draft;
    private List<Course> _enrolmentCourses { get; set; } = new List<Course>();

    public void Submit() { _enrolmentStatus = EnrolmentStatus.Pending; }
    public void Cancel() { _enrolmentStatus = EnrolmentStatus.Rejected; }
    public void Resubmit() { _enrolmentStatus = EnrolmentStatus.Pending; }
    public void GetEnrolmentRequestDetails() => Console.WriteLine($"Request {_requestId} is {_enrolmentStatus}");
}