﻿// Defines the possible statuses of an enrolment request throughout the enrolment lifecycle in the Course Enrolment System
public enum EnrolmentStatus
{
    Draft,
    Pending,
    Approved,
    Rejected,
    Confirmed,
    Cancelled
}