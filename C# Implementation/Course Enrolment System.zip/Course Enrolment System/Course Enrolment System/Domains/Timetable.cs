﻿// Represents a Timetable entity in the Course Enrolment System.
// Stores schedule information including day, time, and location.
public class Timetable
{
    private static int _timetableCounter = 0; // Used to generate sequential timetable IDs
    private string _timetableId { get; init; } // Unique Timetable ID with prefix TT (e.g., TT0001)
    public string Day { get; set; }
    public string StartTime { get; set; }
    public string EndTime { get; set; }
    public string Location { get; set; }

    // Constructor
    public Timetable(string day, string startTime, string endTime, string location)
    {
        _timetableId = "TT" + _timetableCounter.ToString("D6"); // 6-digit format
        _timetableCounter++;
        Day = day;
        StartTime = startTime;
        EndTime = endTime;
        Location = location;
    }

    // Display timetable information
    public void DisplayTimetable()
    {
        Console.WriteLine($"[{Day}] {StartTime}-{EndTime} at {Location}");
    }
}