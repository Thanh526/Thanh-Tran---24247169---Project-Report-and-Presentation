﻿public class Timetable
{
    private string _timetableId { get; init; }
    public string Day { get; set; }
    public string StartTime { get; set; }
    public string EndTime { get; set; }
    public string Location { get; set; }

    // Constructor
    public Timetable(string timetableId, string day, string startTime, string endTime, string location)
    {
        _timetableId = timetableId;
        Day = day;
        StartTime = startTime;
        EndTime = endTime;
        Location = location;
    }

    public void DisplayTimetable()
    {
        Console.WriteLine($"[{Day}] {StartTime}-{EndTime} at {Location}");
    }
}