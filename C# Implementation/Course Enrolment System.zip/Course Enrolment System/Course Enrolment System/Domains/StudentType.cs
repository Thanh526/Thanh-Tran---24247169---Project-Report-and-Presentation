﻿public enum StudentType
{
    Domestic,
    International
}