﻿// Defines the type of student in the Course Enrolment System
public enum StudentType
{
    Domestic,
    International
}