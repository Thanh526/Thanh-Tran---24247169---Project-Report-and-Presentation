﻿// Represents a base User in the Course Enrolment System.
// Handles authentication, login/logout operations, and password management.
// Also manages access control to determine whether a user is allowed to log in.
public abstract class User
{
    private static int _userCounter = 0; // Used to generate sequential user IDs
    protected string _userID { get; }
    public string Username { get; set; }
    private string _password { get; set; }
    private bool _isAccessAllowed { get; set; } = true;


    // Contructor
    public User(string username, string password)
    {
        _userID = _userCounter.ToString("D6"); // 6-digit format
        _userCounter++;
        Username = username;
        _password = password;
    }

    // Login
    public void Login(string username, string password)
    {
        // Verify credentials
        if (Username == username && _password == password && _isAccessAllowed)
        {
            AuditService.Instance.LogActivity(this._userID, "Successful login", DateTime.Now);
            Console.WriteLine($"{Username} logged in successfully.");
        }
        else
        {
            AuditService.Instance.LogActivity(this._userID ?? username, "Failed login", DateTime.Now);
            Console.WriteLine("Login failed. Invalid credentials.");
        }
    }

    // Logout
    public void Logout()
    {
        AuditService.Instance.LogActivity(this._userID, "User logout", DateTime.Now);

        Console.WriteLine($"Session ended for {Username}.");
        Console.WriteLine($"You have been successfully logged out.");
    }

    // Reset password
    public void ResetPassword(string oldPassword, string newPassword)
    {
        if (_password == oldPassword)
        {
            _password = newPassword;
            Console.WriteLine("Password updated successfully.");
        }
        else
        {
            Console.WriteLine("Verification failed. Password not changed.");
        }
    }

    // Set access
    public void SetAccess(User admin, bool allowAccess)
    {
        // Verify admin
        if (admin is not SystemAdmin)
        {
            AuditService.Instance.LogActivity(_userID, $"Unauthorized access change attempt by {admin.Username}", DateTime.Now);
            Console.WriteLine("Access denied. Only admin can change access.");
            return;
        }

        _isAccessAllowed = allowAccess;

        AuditService.Instance.LogActivity(_userID, allowAccess ? "Access granted" : "Access revoked", DateTime.Now);
        Console.WriteLine($"Access updated for {Username}");
    }
}