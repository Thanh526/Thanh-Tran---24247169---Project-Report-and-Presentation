﻿// Represents Registry Staff in the Course Enrolment System.
// Responsible for monitoring and reviewing student enrolment requests, checking student eligibility, and approving or rejecting enrolments.
public class RegistryStaff : Staff
{
    public string OfficeLocation { get; private set; }

    public RegistryStaff(string staffID, string username, string password)
        : base(staffID, username, password)
    {
        Department = "Registry";
    }

    // Assign office location to registry staff
    public void SetFaculty(string officeLocation)
    {
        OfficeLocation = officeLocation;
    }

    // Monitor all enrolment requests
    public void MonitorEnrolments()
    {
        List<EnrolmentRequest> requests =
            EnrolmentRepository.GetAll();

        Console.WriteLine("----- ALL ENROLMENTS -----");

        foreach (var r in requests)
        {
            Console.WriteLine(
                $"ID: {r.GetRequestID()} | " +
                $"Status: {r.GetStatus()}"
            );
        }
    }

    // Review one enrolment request
    public void ReviewEnrolmentRequest(string requestId)
    {
        var request = EnrolmentRepository.GetAll()
            .FirstOrDefault(r => r.GetRequestID() == requestId);

        if (request == null)
        {
            Console.WriteLine("Request not found.");
            return;
        }

        Console.WriteLine("---- REQUEST DETAILS ----");
        Console.WriteLine($"Request ID: {request.GetRequestID()}");
        Console.WriteLine($"Student ID: {request.StudentId}");
        Console.WriteLine($"Status: {request.GetStatus()}");
        Console.WriteLine($"Submitted Date: {request.SubmissionDate}");

        Console.WriteLine("Courses:");
        foreach (var c in request.GetCourses())
        {
            Console.WriteLine($"- {c.CourseCode} {c.CourseName}");
        }
    }

    // Check student eligibility
    public bool CheckStudentEligibility(
    string studentId,
    FinanceService financeService)
    {
        bool eligible =
            financeService.CheckFinancialEligibility(
                studentId,
                StudentType.International // or get from system
            );

        return eligible;
    }

    // Approve request
    public void ApproveEnrolment(
    string requestId,
    NotificationService notificationService)
    {
        var request = EnrolmentRepository.GetAll()
            .FirstOrDefault(r => r.GetRequestID() == requestId);

        if (request == null)
        {
            Console.WriteLine("Request not found.");
            return;
        }

        request.Approve();

        notificationService.Notify("Enrolment approved: " + requestId);

        Console.WriteLine("Request approved.");
    }

    // Reject request
    public void RejectEnrolment(
    string requestId,
    NotificationService notificationService)
    {
        var request = EnrolmentRepository.GetAll()
            .FirstOrDefault(r => r.GetRequestID() == requestId);

        if (request == null)
        {
            Console.WriteLine("Request not found.");
            return;
        }

        request.Reject();

        notificationService.Notify("Enrolment rejected: " + requestId);

        Console.WriteLine("Request rejected.");
    }
}