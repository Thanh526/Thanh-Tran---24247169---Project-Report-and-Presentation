﻿// Represents Finance Staff in the Course Enrolment System.
// Responsible for handling student financial matters such as viewing payment status and managing payment-related issues.
public class FinanceStaff : Staff
{
    private IFinanceSystem _financeSystem { get; init; }
    public string FinanceUnit { get; private set; }

    // Constructor
    public FinanceStaff(string staffID, string username, string password)
        : base(staffID, username, password)
    {
        Department = "Finance";
    }

    // Assign finance unit to finance staff
    public void SetFinanceUnit(string financeUnit)
    {
        FinanceUnit = financeUnit;
    }

    // View payment status using IFinanceSystem
    public void ViewPaymentStatus(string studentId)
    {
        PaymentStatus status = _financeSystem.GetPaymentStatus(studentId);

        Console.WriteLine("------ Payment Status ------");
        Console.WriteLine($"Paid: {status.PaidAmount}");
        Console.WriteLine($"Outstanding: {status.OutstandingAmount}");
        Console.WriteLine($"Status: {status.Status}");
    }

    // Navigate to finance system for handling payment exception
    public void HandlePaymentException()
    {
        Console.WriteLine("Opening Finance System for handling payment exception");
    }
}