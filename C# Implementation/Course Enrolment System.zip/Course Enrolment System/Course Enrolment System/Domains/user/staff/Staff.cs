﻿// Represents the abstract Staff class in the Course Enrolment System.
// Inherits from User and provides shared attributes and behaviours for all staff types.
// Includes auto-generated staff ID and department information.
public abstract class Staff : User
{
    private static int _staffCounter = 0; // Used to generate sequential staff IDs
    private string _staffID { get; init; }
    public string Department { get; protected set; } // Department assigned to the staff member (e.g., Academic, Finance, IT)

    // Constructor 
    public Staff(string staffID, string username, string password)
        : base(staffID, username, password) { }
}