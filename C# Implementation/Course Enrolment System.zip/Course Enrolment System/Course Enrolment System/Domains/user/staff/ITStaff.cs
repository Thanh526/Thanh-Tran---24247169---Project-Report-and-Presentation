﻿// Represents an IT staff member responsible for system maintenance, technical support, and system reliability.
public class ITStaff : Staff
{
    public string TechnicalArea { get; private set; }

    // Constructor
    public ITStaff(string staffID, string username, string password)
        : base(staffID, username, password)
    {
        Department = "IT";
    }

    // Assign technical area to IT staff
    public void SetFaculty(string technicalArea)
    {
        TechnicalArea = technicalArea;
    }

    // Monitor system performance
    public void MonitorSystemPerformance()
    {
        AuditService.Instance.LogActivity(_userID, "Monitored system performance", DateTime.Now);
        Console.WriteLine("Monitoring system performance...");
    }

    // Maintain system uptime
    public void MaintainSystemUptime()
    {
        AuditService.Instance.LogActivity(_userID, "Maintained system uptime", DateTime.Now);
        Console.WriteLine("Maintaining system uptime...");
    }

    // Resolve technical issues
    public void ResolveTechnicalIssues()
    {
        AuditService.Instance.LogActivity(_userID, "Resolved technical issues", DateTime.Now);
        Console.WriteLine("Resolving technical issues...");
    }

    // Validate data consistency
    public void ValidateDataConsistency()
    {
        AuditService.Instance.LogActivity(_userID, "Validated data consistency", DateTime.Now);
        Console.WriteLine("Validating data consistency...");
    }
}