﻿// Represents academic staff in the Course Enrolment System. Responsible for viewing course
// information, managing courses, granting overrides, and handling faculty assignment.
public class AcademicStaff : Staff
{
    public string Faculty { get; private set; }

    // Contructor
    public AcademicStaff(string staffID, string username, string password)
        : base(staffID, username, password)
    {
        Department = "Academic";
    }

    // Assign faculty to academic staff
    public void SetFaculty(string faculty)
    {
        Faculty = faculty;
    }

    // Display course details 
    public void ViewCourseDetails(CourseService courseService, string courseCode)
    {
        Course course = courseService.GetCourse(courseCode);

        if (course == null)
        {
            Console.WriteLine("Course not found.");
            return;
        }

        Console.WriteLine("-------------- Course details ---------------");
        Console.WriteLine($"Code: {course.CourseCode}");
        Console.WriteLine($"Name: {course.CourseName}");
        Console.WriteLine($"Description: {course.Description}");
        Console.WriteLine($"Credits: {course.Credits}");
        Console.WriteLine($"Remaining Capacity: {course.Capacity}");
        Console.Write("Prerequisites: ");
        if (course.Prerequisites.Count == 0) Console.Write("None");
        else Console.Write(string.Join(", ", course.Prerequisites.Select(p => p.CourseCode)));
        Console.WriteLine("\n------------------------------------------");
    }

    // Navigate to course system for managing course
    public void ManageCourse() 
    {
        Console.WriteLine("Opening Course System for managing course");
    }

    // Navigate to course system for granting override
    public void GrantOverride()
    {
        Console.WriteLine("Opening Course System for granting override");
    }
}