﻿// Represents a Student user in the Course Enrolment System.
// Responsible for managing course enrolment activities.
public class Student : User
{
    public string Programme { get; private set; }
    public StudentType StudentType { get; private set; } // Domestic/International
    private List<Course> _selectedCourses { get; set; } = new List<Course>();
    private List<EnrolmentRequest> _enrolmentRequests { get; set; } = new List<EnrolmentRequest>();
    public List<string> CompletedCourses { get; private set; } = new List<string>();

    // Constructor
    public Student(string _userID, string username, string password)
        : base(_userID, username, password) { }

    // Set student's programme
    public void SetProgramme(string programme)
    {
        Programme = programme;
    }

    // Set student type (Domestic / International)
    public void SetStudentType(StudentType type)
    {
        StudentType = type;
    }

    // Add student's completed course
    public void AddCompletedCourse(string courseCode)
    {
        if (!CompletedCourses.Contains(courseCode))
            CompletedCourses.Add(courseCode);
    }

    // Search all courses
    public void SearchCourses(CourseService courseService)
    {
        List<Course> courses = courseService.GetAllCourses();

        Console.WriteLine("---------- Available Courses ----------");

        foreach (var course in courses)
        {
            Console.WriteLine($"{course.CourseCode} - {course.CourseName}");
        }

        Console.WriteLine("--------------------------------------");
    }

    // View course detail
    public void ViewCourseDetails(CourseService courseService, string courseCode)
    {
        Course course = courseService.GetCourse(courseCode);

        if (course == null)
        {
            Console.WriteLine("Course not found.");
            return;
        }

        Console.WriteLine("-------------- Course details ---------------");
        Console.WriteLine($"Code: {course.CourseCode}");
        Console.WriteLine($"Name: {course.CourseName}");
        Console.WriteLine($"Description: {course.Description}");
        Console.WriteLine($"Credits: {course.Credits}");
        Console.WriteLine($"Remaining Capacity: {course.Capacity}");
        Console.Write("Prerequisites: ");
        if (course.Prerequisites.Count == 0) Console.Write("None");
        else Console.Write(string.Join(", ", course.Prerequisites.Select(p => p.CourseCode)));
        Console.WriteLine("\n------------------------------------------");
    }

    // Add course to selected courses list
    public void SelectCourse(Course course, ValidationService validationService)
    {
        // Check capacity
        if (!validationService.CheckCourseCapacity(course))
        {
            Console.WriteLine(
                $"Cannot select {course.CourseCode}: Course is full."
            );
            return;
        }

        // Check prerequisites
        if (!validationService.ValidatePrerequisites(this, course))
        {
            Console.WriteLine(
                $"Cannot select {course.CourseCode}: Missing prerequisites."
            );
            return;
        }

        // Prevent duplicate selection
        if (_selectedCourses.Any(c => c.CourseCode == course.CourseCode))
        {
            Console.WriteLine(
                $"{course.CourseCode} is already selected."
            );
            return;
        }

        _selectedCourses.Add(course);

        Console.WriteLine(
            $"Course {course.CourseCode} added to your selection."
        );
    }

    // Set selected courses list
    public List<Course> GetSelectedCourses() {  return _selectedCourses; }
    public void ViewEnrolledList()
    {
        Console.WriteLine("--- Selected courses ---");

        if (_selectedCourses.Count == 0)
        {
            Console.WriteLine("No courses selected yet.");
        }
        else
        {
            foreach (var course in _selectedCourses)
            {
                Console.WriteLine($"> {course.CourseCode} - {course.CourseName} ({course.Credits} Credits)");
            }
            Console.WriteLine("\n------------------------------------------");
        }
    }

    // View time table
    public void ViewTimetable(Timetable timetable)
    {
        Console.WriteLine($"Generating timetable for {_userID}...");
        timetable.DisplayTimetable();
    }

    // Submit enrolment
    public void SubmitEnrolment()
    {
        // No selected course
        if (_selectedCourses.Count == 0)
        {
            Console.WriteLine("No selected courses to submit.");
            return;
        }

        // Check duplicates against existing requests
        var alreadyRequestedCourses = _enrolmentRequests
            .SelectMany(r => r.GetCourses())
            .Select(c => c.CourseCode)
            .ToHashSet();

        foreach (var course in _selectedCourses)
        {
            if (alreadyRequestedCourses.Contains(course.CourseCode))
            {
                Console.WriteLine(
                    $"Cannot submit: {course.CourseCode} already exists in previous request."
                );
                return;
            }
        }

        // Create enrolment request
        EnrolmentRequest request = new EnrolmentRequest(_userID);

        // Add selected courses into request
        request.SetCourses(_selectedCourses);

        // Submit request
        request.Submit();

        // Store request
        _enrolmentRequests.Add(request);
        EnrolmentRepository.Add(request);


        Console.WriteLine("Enrolment request submitted successfully.");

        // Clear temporary selected courses
        _selectedCourses.Clear();
    }

    // View enrolment status
    public void ViewEnrolmentStatus()
    {
        if (_enrolmentRequests.Count == 0)
        {
            Console.WriteLine("No enrolment requests found.");
            return;
        }

        Console.WriteLine("----- Enrolment Requests -----");

        foreach (var request in _enrolmentRequests)
        {
            request.GetEnrolmentRequestDetails();
        }
    }
}