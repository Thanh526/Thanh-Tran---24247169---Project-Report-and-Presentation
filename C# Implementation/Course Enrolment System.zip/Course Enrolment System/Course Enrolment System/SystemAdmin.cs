﻿public class SystemAdmin : Staff
{
    public string AdminLevel { get; set; }

    public void ManageUserAccess() { }
    public void SetSystemConfiguration() { }
    public void ReviewAuditLogs() { }
}