﻿public class SystemAdmin : Staff
{
    public string AdminLevel { get; set; }

    public SystemAdmin(string userId, string username, string password, string staffId, string dept, string adminLevel)
        : base(userId, username, password, staffId, dept)
    {
        this.AdminLevel = adminLevel;
    }
    public void ManageUserAccess() { }
    public void SetSystemConfiguration() { }
    public void ReviewAuditLogs() { }
}