﻿public class RegistryStaff : Staff
{
    public string OfficeLocation { get; set; }

    public void MonitorEnrolments() { }
    public void ReviewEnrolmentRequest() { }
    public void CheckStudentEligibility() { }
    public void ApproveEnrolment() { }
    public void RejectEnrolment() { }
}