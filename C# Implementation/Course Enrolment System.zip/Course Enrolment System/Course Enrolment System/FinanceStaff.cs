﻿public class FinanceStaff : Staff
{
    public string FinanceUnit { get; set; }

    public void ViewPaymentStatus() { }
    public void HandlePaymentException() { }
}