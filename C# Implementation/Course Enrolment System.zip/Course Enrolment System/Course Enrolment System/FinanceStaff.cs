﻿public class FinanceStaff : Staff
{
    public string FinanceUnit { get; set; }

    public FinanceStaff(string userId, string username, string password, string staffId, string dept, string financeUnit)
        : base(userId, username, password, staffId, dept)
    {
        this.FinanceUnit = financeUnit;
    }
    public void ViewPaymentStatus() { }
    public void HandlePaymentException() { }
}