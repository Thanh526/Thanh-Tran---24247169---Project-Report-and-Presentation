﻿using System;
using System.Collections.Generic;

public class Course
{
    public string CourseCode { get; private set; }
    public string CourseName { get; private set; }
    public string Description { get; set; }
    public int Credits { get; private set; }
    public int Capacity { get; private set; }
    public int EnrolledCount { get; private set; }
    public List<string> Prerequisites { get; private set; }

    public Course(string code, string name, int credits, int capacity)
    {
        this.CourseCode = code;
        this.CourseName = name;
        this.Credits = credits;
        this.Capacity = capacity;
        this.EnrolledCount = 0;
        this.Prerequisites = new List<string>();
    }

    public void UpdateCapacity(int value)
    {
        if (value >= EnrolledCount)
        {
            this.Capacity = value;
            Console.WriteLine($"{CourseCode} capacity updated to {value}.");
        }
        else
        {
            Console.WriteLine($"Update denied for {CourseCode}:");
            Console.WriteLine($" - Requested capacity: {value}");
            Console.WriteLine($" - Current enrolments: {EnrolledCount}");
        }
    }
    public List<string> GetPrerequisites() { return Prerequisites; }
    public bool IsAvailable()
    {
        return EnrolledCount < Capacity;
    }
    public void IncrementEnrolment()
    {
        if (IsAvailable())
        {
            EnrolledCount++;
        }
    }
    public void AddPrerequisite(string courseCode)
    {
        if (!Prerequisites.Contains(courseCode))
        {
            Prerequisites.Add(courseCode);
        }
    }
    public string GetFullDetails()
    {
        string prereqs = Prerequisites.Count > 0 ? string.Join(", ", Prerequisites) : "None";
        return $"{CourseCode}: {CourseName}\n" +
               $"Credits: {Credits}\n" +
               $"Prerequisites: {prereqs}\n" +
               $"Availability: {Capacity - EnrolledCount} spots remaining.";
    }
}