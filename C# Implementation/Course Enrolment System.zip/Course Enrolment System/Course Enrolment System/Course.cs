﻿public class Course
{
    public string CourseId { get; private set; }
    public string CourseCode { get; set; }
    public string CourseName { get; set; }
    public string Description { get; set; }
    public List<string> Prerequisites { get; private set; }
    public int Capacity { get; private set; }
    public int Credits { get; private set; }

    public bool IsAvailable() { return true; }
    public void UpdateCapacity(int value) { }
    public List<string> GetPrerequisites() { return Prerequisites; }
}