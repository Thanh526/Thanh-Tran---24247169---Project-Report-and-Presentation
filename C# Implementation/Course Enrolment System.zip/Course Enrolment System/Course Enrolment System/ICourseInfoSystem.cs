﻿public interface ICourseInfoSystem
{
    void GetCourseInfo(string courseId);
    void UpdateCourse(string courseId);
}