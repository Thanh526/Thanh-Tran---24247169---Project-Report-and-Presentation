﻿public class AuditService
{
    public void LogActivity(string userId, string action, DateTime timestamp) { }
}