﻿using System;
using System.Collections.Generic;

public class Student : User
{
    public string StudentId { get; private set; }
    public string Programme { get; set; }
    public StudentType StudentType { get; private set; }
    private List<Course> _selectedCourses = new List<Course>();
    private List<EnrolmentRequest> _enrolmentRequests = new List<EnrolmentRequest>();

    public Student(string userId, string username, string password, string studentId, string programme, StudentType type)
        : base(userId, username, password)
    {
        this.StudentId = studentId;
        this.Programme = programme;
        this.StudentType = type;
    }

    public void SearchCourses(ICourseInfoSystem cis)
    {
        Console.WriteLine($"--- Searching AUT database for {this.Programme} ---");
        cis.GetCourseInfo("ALL");
    }
    public void SelectCourses(Course course)
    {
        if (course.IsAvailable())
        {
            _selectedCourses.Add(course);
            Console.WriteLine($"Course {course.CourseCode} added to your selection.");
        }
        else
        {
            Console.WriteLine($"Cannot select {course.CourseCode}: Course is at full capacity.");
        }
    }
    public void ViewCourses(Course course)
    {
        Console.WriteLine("--- Course details (Dropdown) ---");
        Console.WriteLine($"Code: {course.CourseCode}");
        Console.WriteLine($"Name: {course.CourseName}");
        Console.WriteLine($"Description: {course.Description}");
        Console.WriteLine($"Credits: {course.Credits}");
        Console.WriteLine($"Current Capacity: {course.Capacity}");

        Console.Write("Prerequisites: ");
        if (course.Prerequisites.Count == 0) Console.Write("None");
        else Console.Write(string.Join(", ", course.Prerequisites));
        Console.WriteLine("\n------------------------------------------");
    }
    public void ViewEnrolledList()
    {
        Console.WriteLine("--- Selected courses ---");

        if (_selectedCourses.Count == 0)
        {
            Console.WriteLine("No courses selected yet.");
        }
        else
        {
            foreach (var course in _selectedCourses)
            {
                Console.WriteLine($"> {course.CourseCode} - {course.CourseName} ({course.Credits} Credits)");
            }
            Console.WriteLine("\n------------------------------------------");
        }
    }
    public void ViewTimetable(Timetable timetable)
    {
        Console.WriteLine($"Generating timetable for {StudentId}...");
        timetable.DisplayTimetable();
    }

    public void SubmitEnrolment(AuditService audit)
    {
        if (_selectedCourses.Count == 0)
        {
            Console.WriteLine("Submission failed: No courses selected.");
            return;
        }

        string newRequestId = "REQ-" + Guid.NewGuid().ToString().Substring(0, 5).ToUpper();
        EnrolmentRequest newRequest = new EnrolmentRequest(newRequestId, StudentId, _selectedCourses);

        newRequest.Submit();

        _enrolmentRequests.Add(newRequest);
        _selectedCourses.Clear();

        audit.LogActivity(this.UserId, $"Submitted Enrolment {newRequestId}", DateTime.Now);

        Console.WriteLine($"Enrolment request {newRequestId} has been submitted successfully.");
    }

    public void ModifyEnrolmentRequest(string requestId)
    {
        var request = _enrolmentRequests.Find(r => r.RequestId == requestId);

        if (request != null && request.EnrolmentStatus == EnrolmentStatus.Pending)
        {
            request.Cancel();
            Console.WriteLine($"Request {requestId} has been pulled back for modification.");
        }
        else
        {
            Console.WriteLine("Modification error: Request not found or already processed by registry staff.");
        }
    }

    public void ViewEnrolmentStatus()
    {
        Console.WriteLine($"--- Enrolment history for {this.Username} ---");
        if (_enrolmentRequests.Count == 0)
        {
            Console.WriteLine("No enrolment requests found.");
        }
        else
        {
            foreach (var req in _enrolmentRequests)
            {
                Console.WriteLine($"Request ID: {req.RequestId} | Submitted: {req.SubmissionDate.ToShortDateString()} | Status: {req.EnrolmentStatus}");
            }
        }
        Console.WriteLine("\n------------------------------------------");
    }
}