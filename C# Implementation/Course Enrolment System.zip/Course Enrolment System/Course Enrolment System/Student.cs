﻿public class Student : User
{
    public string StudentId { get; private set; }
    public string Programme { get; set; }
    public StudentType StudentType { get; private set; }

    public void SearchCourses() { }
    public void SelectCourses() { }
    public void ViewCourses() { }
    public void ViewTimetable() { }
    public void SubmitEnrolment() { }
    public void ModifyEnrolmentRequest() { }
    public void ViewEnrolmentStatus() { }
}