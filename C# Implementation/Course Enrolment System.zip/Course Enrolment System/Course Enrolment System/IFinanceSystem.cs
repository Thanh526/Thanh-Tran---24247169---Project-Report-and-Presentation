﻿public interface IFinanceSystem
{
    void GetPaymentStatus(string studentId);
    void VerifyInsurance(string studentId);
    void CheckFinancialPolicy(string studentId);
}