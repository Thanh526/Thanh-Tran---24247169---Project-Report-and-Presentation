﻿// Service layer responsible for handling course-related operations.
// Acts as a bridge between the system and external course information system via ICourseInfoSystem.
public class CourseService
{
    private ICourseInfoSystem _courseSystem { get; init; }

    // Constructor
    public CourseService(ICourseInfoSystem courseSystem)
    {
        _courseSystem = courseSystem;
    }

    // Get all course from external system via adapter
    public List<Course> GetAllCourses()
    {
        return _courseSystem.GetAllCourses();
    }

    // Get course from external system via adapter
    public Course GetCourse(string courseCode)
    {
        return _courseSystem.GetCourseInfo(courseCode);
    }

    // Check availability
    public bool IsAvailable(string courseCode)
    {
        return _courseSystem.CheckCourseAvailability(courseCode);
    }
}