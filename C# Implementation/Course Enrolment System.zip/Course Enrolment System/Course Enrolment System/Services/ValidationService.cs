﻿// Handles validation rules for course enrolment
// Ensures student meets prerequisites and course availability rules
public class ValidationService
{
    // Validate if student meets course prerequisites
    public bool ValidatePrerequisites(Student student, Course course)
    {
        foreach (var prereq in course.Prerequisites)
        {
            if (!student.CompletedCourses.Contains(prereq.CourseCode))
            {
                Console.WriteLine($"Missing prerequisite: {prereq.CourseCode}");
                return false;
            }
        }

        return true;
    }

    // Check if course has available capacity
    public bool CheckCourseCapacity(Course course)
    {
        if (course.Capacity <= 0)
        {
            Console.WriteLine("Course is full.");
            return false;
        }

        return true;
    }
}