﻿public class TimetableService
{
    public void DetectTimetableClashes() { }
}