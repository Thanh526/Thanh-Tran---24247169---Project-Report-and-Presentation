﻿// Handles system notifications related to enrolment and student actions
public class NotificationService
{
    // Notify student about enrolment issues (e.g. finance, validation, capacity)
    public void NotifyEnrolmentIssues(Student student, string issues)
    {
        Console.WriteLine("------ Enrolment Notification ------");
        Console.WriteLine($"To: {student.Username} ({student.GetUserID()})");
        Console.WriteLine($"Message: {issues}");
        Console.WriteLine("-------------------------------------");
    }

    // Notify successful enrolment
    public void NotifyEnrolmentSuccess(Student student)
    {
        Console.WriteLine("------ Enrolment Success ------");
        Console.WriteLine($"Congratulations {student.Username}!");
        Console.WriteLine("Your enrolment has been confirmed.");
        Console.WriteLine("--------------------------------");
    }

    // General system message
    public void Notify(string message)
    {
        Console.WriteLine("------ System Notification ------");
        Console.WriteLine(message);
        Console.WriteLine("--------------------------------");
    }
}