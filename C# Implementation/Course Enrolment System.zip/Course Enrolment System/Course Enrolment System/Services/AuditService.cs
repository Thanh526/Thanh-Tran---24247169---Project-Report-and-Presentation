﻿using System;

// Singleton class
public sealed class AuditService
{
    // Lazy initialization guarantees a single, thread-safe instance
    private static readonly Lazy<AuditService> _instance =
        new Lazy<AuditService>(() => new AuditService());

    // Store logs
    private List<string> _logs = new List<string>();

    // Private constructor prevents external instantiation
    private AuditService()
    {
        Console.WriteLine("[SYSTEM] Audit Service Initialized.");
    }

    // Public global access point to the single instance
    public static AuditService Instance
    {
        get { return _instance.Value; }
    }

    // Log activity
    public void LogActivity(string userId, string action, DateTime timestamp)
    {
        string log = $"[AUDIT | {timestamp:HH:mm:ss}] User: {userId} | Action: {action}";
        _logs.Add(log);
        Console.WriteLine(log);
    }

    // Review all audit logs (for admin)
    public void ViewAuditLogs()
    {
        Console.WriteLine("------ AUDIT LOGS ------");

        if (_logs.Count == 0)
        {
            Console.WriteLine("No logs available.");
            return;
        }

        foreach (var log in _logs)
        {
            Console.WriteLine(log);
        }

        Console.WriteLine("------------------------");
    }
}