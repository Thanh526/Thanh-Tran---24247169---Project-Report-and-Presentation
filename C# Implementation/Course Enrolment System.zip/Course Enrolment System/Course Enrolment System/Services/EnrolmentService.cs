﻿// Handles final enrolment confirmation process
public class EnrolmentService
{
    private readonly ValidationService _validationService;
    private readonly FinanceService _financeService;
    private readonly NotificationService _notificationService;

    public EnrolmentService(
        ValidationService validationService,
        FinanceService financeService,
        NotificationService notificationService)
    {
        _validationService = validationService;
        _financeService = financeService;
        _notificationService = notificationService;
    }

    // Confirm student's enrolment request
    public bool ConfirmEnrolment(Student student)
    {
        Console.WriteLine("------ Enrolment Confirmation ------");

        // 1. Check financial eligibility
        bool eligible = _financeService.CheckFinancialEligibility(
            student.GetUserID(),
            student.StudentType
        );

        if (!eligible)
        {
            _notificationService.NotifyEnrolmentIssues(
                student,
                "Financial eligibility failed."
            );
            return false;
        }

            // 2. Check if student has selected courses
            if (student.GetSelectedCourses().Count == 0)
        {
            Console.WriteLine("Enrolment failed: No selected courses.");
            return false;
        }

        // 3. Validate all courses
        foreach (var course in student.GetSelectedCourses())
        {
            if (!_validationService.CheckCourseCapacity(course) ||
                !_validationService.ValidatePrerequisites(student, course))
            {
                Console.WriteLine(
                    $"Enrolment failed: Validation failed for {course.CourseCode}"
                );
                return false;
            }
        }

        // 4. Create enrolment request
        student.SubmitEnrolment();

        Console.WriteLine("Enrolment successfully confirmed.");
        return true;
    }
}