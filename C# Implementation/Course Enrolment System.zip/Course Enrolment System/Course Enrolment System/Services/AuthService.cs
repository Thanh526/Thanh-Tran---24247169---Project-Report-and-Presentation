﻿// Handles authentication logic and user object creation
public class AuthService
{
    private readonly IAuthSystem _authSystem;
    private static Dictionary<string, User> _activeUsers
    = new Dictionary<string, User>();

    // Constructor
    public AuthService(IAuthSystem authSystem)
    {
        _authSystem = authSystem;
    }

    public User Login(string username, string password)
    {
        UserData data = _authSystem.ValidateLogin(username, password);

        if (data == null)
        {
            Console.WriteLine("Login failed.");
            return null;
        }

        // Check if user already exists
        if (_activeUsers.ContainsKey(data.UserId))
        {
            Console.WriteLine("User already logged in. Returning existing session.");
            return _activeUsers[data.UserId];
        }

        User user;

        if (data.Role == "Student")
        {
            Student student = (Student)new StudentCreator()
                .CreateUser(data.UserId, username, password);

            IStudentInfoSystem studentInfoSystem = new StudentInfoAdapter();
            AcademicRecord record =
                studentInfoSystem.GetAcademicRecord(data.UserId);

            student.SetProgramme(record.Programme);
            student.SetStudentType(record.StudentType);

            foreach (var courseCode in record.FinishedCourses)
            {
                student.AddCompletedCourse(courseCode);
            }

            user = student;
        }
        else if (data.Role == "AcademicStaff")
            user = new AcademicStaffCreator()
                .CreateUser(data.UserId, username, password);
        else if (data.Role == "SystemAdmin")
            user = new SystemAdminCreator()
                .CreateUser(data.UserId, username, password);
        else if (data.Role == "RegistryStaff")
            user = new RegistryStaffCreator()
                .CreateUser(data.UserId, username, password);
        else if (data.Role == "FinanceStaff")
            user = new FinanceStaffCreator()
                .CreateUser(data.UserId, username, password);
        else if (data.Role == "ITStaff")
            user = new ITStaffCreator()
                .CreateUser(data.UserId, username, password);
        else
        {
            Console.WriteLine("Invalid role");
            return null;
        }

        // Store session
        _activeUsers[data.UserId] = user;

        return user;
    }
    public void Logout(string userId)
    {
        if (_activeUsers.ContainsKey(userId))
        {
            _activeUsers.Remove(userId);
            Console.WriteLine("User logged out and session cleared.");
        }
    }
}