﻿// Handles finance-related business logic for students
public class FinanceService
{
    private readonly IFinanceSystem _financeSystem;

    public FinanceService(IFinanceSystem financeSystem)
    {
        _financeSystem = financeSystem;
    }

    // Check whether a student is financially eligible (e.g. allowed to enrol)
    public bool CheckFinancialEligibility(string studentId, StudentType type)
    {
        PaymentStatus status = _financeSystem.GetPaymentStatus(studentId);
        bool insuranceValid = _financeSystem.VerifyInsurance(studentId);

        Console.WriteLine("------ Financial Eligibility Check ------");
        Console.WriteLine($"Student ID: {studentId}");
        Console.WriteLine($"Student Type: {type}");
        Console.WriteLine($"Payment Status: {status.Status}");
        Console.WriteLine($"Outstanding Amount: {status.OutstandingAmount}");
        Console.WriteLine($"Insurance Valid: {insuranceValid}");

        if (status.OutstandingAmount > 0 || !insuranceValid)
        {
            Console.WriteLine("Student is NOT financially eligible.");
            return false;
        }
        else
        {
            Console.WriteLine("Student is financially eligible.");
            return true;
        }
    }
}