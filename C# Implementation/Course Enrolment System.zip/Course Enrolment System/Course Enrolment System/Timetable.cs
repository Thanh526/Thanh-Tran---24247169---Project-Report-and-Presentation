﻿public class Timetable
{
    public string TimetableId { get; private set; }
    public string Day { get; set; }
    public string StartTime { get; set; }
    public string EndTime { get; set; }
    public string Location { get; set; }

    public void DisplayTimetable() { }
}