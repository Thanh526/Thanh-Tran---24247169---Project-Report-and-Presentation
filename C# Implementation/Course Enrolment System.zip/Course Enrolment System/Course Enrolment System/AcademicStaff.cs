﻿public class AcademicStaff : Staff
{
    public string Faculty { get; set; }

    public AcademicStaff(string userId, string username, string password, string staffId, string dept, string daculty)
        : base(userId, username, password, staffId, dept)
    {
        this.Faculty = daculty;
    }
    public void ViewCourse() { }
    public void ManageCourse() { }
    public void GrantOverride() { }
}