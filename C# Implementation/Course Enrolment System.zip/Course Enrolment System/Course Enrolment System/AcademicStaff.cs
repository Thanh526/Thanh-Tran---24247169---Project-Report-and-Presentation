﻿public class AcademicStaff : Staff
{
    public string Faculty { get; set; }

    public void ViewCourse() { }
    public void ManageCourse() { }
    public void GrantOverride() { }
}