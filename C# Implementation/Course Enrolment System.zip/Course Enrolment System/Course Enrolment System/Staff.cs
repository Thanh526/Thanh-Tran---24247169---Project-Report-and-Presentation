﻿public abstract class Staff : User
{
    public string StaffId { get; private set; }
    public string Department { get; set; }
}