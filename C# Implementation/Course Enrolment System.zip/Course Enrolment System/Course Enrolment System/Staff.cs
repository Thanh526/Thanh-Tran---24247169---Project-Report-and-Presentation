﻿public abstract class Staff : User
{
    public string StaffId { get; private set; }
    public string Department { get; set; }

    public Staff(string userId, string username, string password, string staffId, string dept)
        : base(userId, username, password)
    {
        this.StaffId = staffId;
        this.Department = dept;
    }
}