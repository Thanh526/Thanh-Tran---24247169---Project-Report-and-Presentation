﻿public class FinanceService
{
    public void CheckFinancialEligibility(string studentId, StudentType type) { }
}