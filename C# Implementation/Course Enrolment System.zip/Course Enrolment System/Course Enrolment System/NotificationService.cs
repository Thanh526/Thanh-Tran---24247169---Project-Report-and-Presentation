﻿public class NotificationService
{
    public void NotifyEnrolmentIssues(Student student, string issues) { }
}