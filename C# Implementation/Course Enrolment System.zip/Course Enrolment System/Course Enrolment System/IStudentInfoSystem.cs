﻿public interface IStudentInfoSystem
{
    void GetStudentInfo(string studentId);
    void GetAcademicRecord(string studentId);
}