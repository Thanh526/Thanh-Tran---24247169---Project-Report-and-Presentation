﻿public class ValidationService
{
    public void ValidatePrerequisites() { }
    public void CheckCourseCapacity() { }
}