﻿public class ITStaff : Staff
{
    public string TechnicalArea { get; set; }

    public ITStaff(string userId, string username, string password, string staffId, string dept, string technicalArea)
        : base(userId, username, password, staffId, dept)
    {
        this.TechnicalArea = technicalArea;
    }
    public void MonitorSystemPerformance() { }
    public void MaintainSystemUptime() { }
    public void ResolveTechnicalIssues() { }
    public void ValidateDataConsistency() { }
}