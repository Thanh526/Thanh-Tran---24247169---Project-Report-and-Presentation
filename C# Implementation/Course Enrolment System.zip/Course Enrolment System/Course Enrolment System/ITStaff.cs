﻿public class ITStaff : Staff
{
    public string TechnicalArea { get; set; }

    public void MonitorSystemPerformance() { }
    public void MaintainSystemUptime() { }
    public void ResolveTechnicalIssues() { }
    public void ValidateDataConsistency() { }
}